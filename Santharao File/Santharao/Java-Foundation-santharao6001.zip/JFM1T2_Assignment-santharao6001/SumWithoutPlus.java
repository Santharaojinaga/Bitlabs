/*  JFM1T2_Assignment5:

    Write a program to print the sum of two numbers without using + operator.
    Prompt the user input from the terminal.
    
    Sample Input:
    Enter first number: 
    22
    Enter second number: 
    50
    
    Expected Output:
    The sum of two numbers is: 72
*/

//import statements for java program to read inputs using Scanner class


public class SumWithoutPlus
{
  public static void main(String args[]){
    int a=22;
    int b=50;
    int c=a+b;
    System.out.println("sum of two number "+c);
  }
}

//check if the second number is less than zero then decrease first number and increase second number

//print result

