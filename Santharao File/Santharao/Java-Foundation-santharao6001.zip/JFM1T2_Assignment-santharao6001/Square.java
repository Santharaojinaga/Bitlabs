class Square
  {
    public static void main(String args[])
    {
      int a,b,c;
      a=5*5;
      b=6*6;
      c=7*7;
      System.out.println("sum of squares "+b);
    }
  }