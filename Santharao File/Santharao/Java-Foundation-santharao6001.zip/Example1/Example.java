// ggg
public class Example{
  public static void main(String args[]){
    int a=5;
    int b=6;
    int c=a+b;
    System.out.println("sum of two number "+c);
  }
}