public class Maximum  {
  public static void main(String args[]){
 //taking value as command line argument.  //Converting String format to Integer value
int i = Integer.parseInt(args[0]);
int j = Integer.parseInt(args[1]);
    if (i> j)
  {
    System.out.println(i+" is grater than "+j);}
  else;
    {
    System.out.println(j+" is grater than "+i);
    }
   }
}
