//JFM1T3_Assignment5:
/*
1.Write a program to initialize a boolean variable and print it's opposite value on console.

  Sample Input:true

  Expected Output:false

*/
public class BooleanOperation
{
public static void main(String args[])
  {
    //these are boolean variables
    boolean user=true;
    if(!user)
    
     {
     System.out.println("true");
       }
    else
    {
       System.out.println("false");
       }
    }
}


//Declare a variable and initialize it as true or false 

//Print the Result using not operator 

