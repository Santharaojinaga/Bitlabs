class Reverce{
   public static void main(String arg[]){
   
      
  for(int i=10;i>=1;i--){

     System.out.println(i);
     }
}
}