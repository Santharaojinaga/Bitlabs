class EvenOdd {
  public static void main(String arg[]){
   
      System.out.println("even numbers");
  for(int i=1;i<=10;i++){
    if(i%2==0)
  System.out.println(i);
    }
     
        System.out.println("odd numbers");
  for(int i=1;i<=10;i++){
    if(i%2!=0)
  System.out.println(i);
       }
     }
    }

