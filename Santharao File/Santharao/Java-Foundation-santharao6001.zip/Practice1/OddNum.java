import java.util.*;
class OddNum{
  public static void main(String args[]){
   Scanner sc=new Scanner(System.in);
    System.out.println("enter numbers");
    int n,i=1,sum=0;
 
      n=sc.nextInt();
     while(i<=n){
       if (i%2!=0)
      System.out.println(i);
       i++;
       }
    }
}