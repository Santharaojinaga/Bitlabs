import java.util.*;
class ReverceNatural_numbers{
  public static void main(String args[]){
    int n;
    Scanner sc=new Scanner(System.in);
    System.out.println("Reverce natural numbers");
    n=sc.nextInt();
    int i=n;
    while(i>=1){
      System.out.println(i);
      i--;
    }
    }
}