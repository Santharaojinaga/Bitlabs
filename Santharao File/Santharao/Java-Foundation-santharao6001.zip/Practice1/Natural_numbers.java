import java.util.*;
class Natural_numbers{
  public static void main(String args[]){
    int sum=0,n;
    Scanner sc=new Scanner(System.in);
    System.out.println("natural numbers");
    n=sc.nextInt();
    int i=1;
    while(i<=n){
      System.out.println(i);
      i++;
    }
    }
}
    