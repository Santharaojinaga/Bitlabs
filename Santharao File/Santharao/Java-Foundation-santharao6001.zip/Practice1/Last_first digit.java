import java.util.*;
  class Last_first digit{
    public static void main(String args[]){
      int count=0,n;
      Scanner sc=new Scanner(System.in);
        System.out.println("enter 'n' value");
       n=sc.nextInt();
      Last digit=n%10;
        while(n>10);{
       n=n/10;
          }
      int first digit=n;
         System.out.println(count);
        }
  }