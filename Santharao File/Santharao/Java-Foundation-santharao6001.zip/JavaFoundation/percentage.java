class Percentage
  {
    public static void main (String arg[])
    {
     int a,b,c,p;
      ;
      a=90;
      b=80;
      c=100;
      p=((a+b+c)/3)+(100/300);
       System.out.println( " percent  is"+p);
    }
  }