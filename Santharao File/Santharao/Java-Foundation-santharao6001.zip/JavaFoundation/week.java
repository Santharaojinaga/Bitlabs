Class week
  {
    public static void main(String avgs[])
    {
    int n=1,2,,4,5,6,7;
    if (n==2)
      case1
      Systemout.println("monday");
      }
    case2
      System out.println("tuesday");
      }
    else
    { if(n==3)
          System  out.println("wednsday")
      default:
      system out.println( "worng choice")
      
           }
  }