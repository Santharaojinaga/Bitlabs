class HelloWorld
  {
    public static void main(String args[])
    {
      //print"Hellow world" in the terminal window.
      System.out.println("Hellow world");
    }
  }




import java.util.*;
// simple electricity bill calculation
 public class Electricity Bill {
 public static void main(String args[]) {

    double billAmount=0
   int unit<=250
     // Frist50 units Rs 0.50/unit;
     //Next 100 units Rs 0.75/unit;
    //Next 100 units Rs 1.20/unit;
    //for unit above 250 Rs 1.50/unit;
    //additional Surchage of 20% is added to bill;
//Using scanner class{
Scanner scan=new Scanner(System.in);
System.out.print("Enter number of units: ");
unit=scan.nextLong();//taking input from user for usage unit}
   if ((unit<=50)&&(usage<=50));
  {
      System.out.println(unit*0.50);
    }
     if((unit<=100)&&(usage<=100))
  {
    System.out.println((unit*0.50)+((unit50)*0.75));
    }
     if ((unit<=200)&&(usage<=200));
    {
      Sytem.out.println((unit*0.50)+(unit*0.75)+((unit100)*1.20));
      }
    else
    {
      System.out.println((unit*0.50)+(unit*0.75)+(unit*1.20)+((unit200)*1.50));
      }
    {
    System.out.println("amount of bill"+ bill);
     System.out.println("total amount of bill"+((bill)+ (bill*20/100)));
      }
}
}
  