import java.until.scanner;
class vowel or not
{
public static void main(string args[])
{
scanner sc=new scannner( system.in);
system.out.printIn("enter any character ");
char ch=sc.next()chart(0);
switch(ch)
{
 case "a":case 'A';
 case "e":case "E"
 case "i"
 case "o"
 case "u"
system.out.println("it is vowel" );
break;
default;
system.out.println("it is cocenent");
}
  }