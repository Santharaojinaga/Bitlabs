class simple
  {
    public static void main (String args[])
    {
int p,t,r,si;
p=5000;
t=30;
r=2;
si=(p*t*r)/100;
 System.out.println("the si is "+si);
      }
}
